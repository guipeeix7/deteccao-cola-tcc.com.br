export class DynamicInputBase<T> {
  value: T|undefined;
  key: string;
  label: string;
  required: boolean;
  order: number;
  controlType: string;
  type: string;
  invalid: boolean;
  options: {key: string, value: string}[];
  multiple: boolean;
  isActive: boolean;
  constructor(options: {
    value?: T;
    key?: string;
    label?: string;
    required?: boolean;
    order?: number;
    controlType?: string;
    type?: string;
    invalid?: boolean;
    multiple?: boolean;
    options?: {key: string, value: string}[];
    isActive?: boolean;
  } = {}) {
    this.value = options.value;
    this.key = options.key || '';
    this.label = options.label || '';
    this.required = !!options.required;
    this.order = options.order === undefined ? 1 : options.order;
    this.controlType = options.controlType || '';
    this.type = options.type || '';
    this.invalid = options.invalid || false;
    this.options = options.options || [];
    this.multiple = options.multiple || false;
    this.isActive = options.isActive || false;
  }
}
