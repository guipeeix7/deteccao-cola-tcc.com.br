import { Component} from '@angular/core';
import { DynamicInputBase } from '../dynamic-input-base';
import { FormGroup } from '@angular/forms';
import { CreateService } from '../../../services/partials/create.service'
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
import { Location } from '@angular/common';
import { animate, style, transition, trigger } from '@angular/animations';


@Component({
  selector: 'app-update-forms',
  templateUrl: './update-forms.component.html',
  styleUrls: ['./update-forms.component.scss'],
    animations: [
    trigger('myInsertRemoveTrigger', [
      transition(':enter', [
        style({ opacity: 0 }),
        animate('500ms', style({ opacity: 1 })),
      ]),
      transition(':leave', [
        animate('500ms', style({ opacity: 0 }))
      ])
  ])]
})
export class UpdateFormsComponent {
  inputs: DynamicInputBase<any>[];
  requestError: boolean = false;
  tableName: string;
  form!: FormGroup;
  payLoad = '';
  created_at = '';
  updated_at = '';
  loading = false;
  disabled = false;
  dataLoaded: Promise<boolean>;
  dataId : number;

  constructor(private inputControlService: CreateService, private router: Router, private route: ActivatedRoute,
    private location:Location){
  }

  ngOnInit(){
    this.tableName = this.route.snapshot.paramMap.get('table');
    this.dataId =   Number(this.route.snapshot.paramMap.get('id'));

    this.inputControlService.getInputDataById(this.tableName, this.dataId).subscribe((resp) => {
      console.log(resp)

      this.convertRequestData(resp)
    });
  }


  hideError(){ //Move this
    this.requestError = false
  }


  convertRequestData(data){
    this.inputs = this.inputControlService.convertDataIntoInputs(data)
    this.created_at = data['data']['created_at']
    this.updated_at = data['data']['updated_at']

    this.form = this.inputControlService.toFormGroup(this.inputs as DynamicInputBase<string>[])
    console.log('thats the form',this.inputs)
    this.dataLoaded = Promise.resolve(true);
  }

  onSubmit(){

    this.payLoad = JSON.stringify(this.form.getRawValue())
    this.requestError = false
    this.loading = true;
    this.disabled = true;

    this.inputControlService.updateDataInputs(this.tableName,this.dataId, this.form.value ).subscribe(resp =>{
        this.loading = false;
        this.disabled = false;

        this.inputControlService.getInputDataById(this.tableName, this.dataId).subscribe((quest) => {
          this.convertRequestData(quest)
        });
        Swal.fire({
          position: 'top-end',
          icon: 'success',
          title: 'Registro atualizado com sucesso',
          showConfirmButton: false,
          timer: 2000
        })
      }
    )
  }
}
