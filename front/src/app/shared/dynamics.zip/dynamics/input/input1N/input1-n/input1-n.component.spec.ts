import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Input1NComponent } from './input1-n.component';

describe('Input1NComponent', () => {
  let component: Input1NComponent;
  let fixture: ComponentFixture<Input1NComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Input1NComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Input1NComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
