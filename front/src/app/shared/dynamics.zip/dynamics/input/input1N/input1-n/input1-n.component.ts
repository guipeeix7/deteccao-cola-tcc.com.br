import { Component } from '@angular/core';

@Component({
  selector: 'app-input1-n',
  templateUrl: './input1-n.component.html',
  styleUrls: ['./input1-n.component.scss']
})
export class Input1NComponent {

}
