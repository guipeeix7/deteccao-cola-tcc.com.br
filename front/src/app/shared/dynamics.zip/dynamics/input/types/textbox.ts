import { DynamicInputBase } from '../../dynamic-input-base';

export class TextboxInput extends DynamicInputBase<string> {
  override controlType = 'textbox';
}
