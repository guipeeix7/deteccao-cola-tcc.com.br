import { DynamicInputBase } from '../../dynamic-input-base';

export class DropdownInput extends DynamicInputBase<string> {
  override controlType = 'dropdown';
  override multiple = true;

}
