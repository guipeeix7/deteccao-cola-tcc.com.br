import { Component, Input } from '@angular/core';
import { FormArray, FormGroup, ValidationErrors } from '@angular/forms';
import { DynamicInputBase } from '../dynamic-input-base';
import { ActivatedRoute, Router } from '@angular/router';
import { NgSelectModule } from '@ng-select/ng-select';

@Component({
  selector: 'app-input',
  templateUrl: './input.component.html',
  styleUrls: ['./input.component.scss']
})
export class InputComponent {
  @Input() input!: DynamicInputBase<string>;
  @Input() form!: FormGroup;
  errorMessages: ValidationErrors;
  protected tableName:string;
  selectedItems = [];


  ngOnInit(){
    
  }

  ngOnChange(){
    console.log('forms values', this.form.getRawValue())
  }

  get isTouched(){
    return this.form.controls[this.input.key].touched;
  }

  setValueForScience(){
    console.log('this makes science', this.form.controls[this.input.key])
  }

  get isValid(){

    this.errorMessages = []
    for(let error in this.form.controls[this.input.key].errors){
      this.errorMessages.push(this.form.controls[this.input.key].errors[error])
    }

    return this.form.controls[this.input.key].valid;
  }
}
