import { Injectable } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
// import { DynamicInputBase } from '../../shared/dynamics/dynamic-input-base';
// import { DropdownInput } from '../../shared/dynamics/input/types/dropdown'
// import { TextboxInput } from '../../shared/dynamics/input/types/textbox'
import { Observable, catchError, map, of } from 'rxjs';
import { environment } from '../../../environments/environment'
import { HttpClient, HttpParams, HttpResponse } from '@angular/common/http';
import { HttpErrorHandlerService } from '../http-errors/http-error-handler.service';
import Swal from 'sweetalert2';

@Injectable({
  providedIn: 'root'
})
export class CreateService {
  API_URL = environment.API_URL;
  /**
   * Following the source https://angular.io/guide/dynamic-form
   * This function will convert an array of inputs into a FormControl instances
   * Then into a FormGroup
   */
  constructor(private http: HttpClient, private httpErrorHandler: HttpErrorHandlerService, private router: Router) { }

  toFormGroup(inputs: DynamicInputBase <string>[] ){
    const group: any = {}

    inputs.forEach(input =>{
      group[input.key] = input.required ?
        new FormControl(input.value || '', Validators.required) :
        new FormControl(input.value || '');
      });
    return new FormGroup(group)
  }

  updateDataInputs(routeFragment:string, id:number, formData:any): Observable<any> {
    return this.http.put<any>(this.API_URL+routeFragment+'/'+id, formData);
  }

  getInputDataById(routeFragment:string, id :number): Observable<any>{
    return this.http.get<any>(this.API_URL+routeFragment+'/'+id);
  }

  handleResponse(resp, form){ //move this
    resp = resp['body']
        if(resp['success'] == false ){

          var responseMessages = resp['data']
          for(let errorField in responseMessages){
            for(let erro in responseMessages[errorField]){
              form.controls[errorField].setErrors({errorField: responseMessages[errorField][erro]});
            }
          }
          // return true;
        }
        else{
          Swal.fire({
            position: 'top-end',
            icon: 'success',
            title: 'Registro inserido com sucesso',
            showConfirmButton: false,
            timer: 2000
          }).then(() => {
            this.router.navigate(['/roles-permissions'])
          })
        }
  }

  convertDataIntoInputs(resp){
    // map(resp => {
      const data = resp['data']
      const fields = resp['fillable']
      const validations = resp['rules']
      const types = resp['dataTypes']

      let fieldOrder = 0;


      // return [formsInputs, data]
    // })
    console.log('cara', Object.entries(types) )
    const formsInputs: DynamicInputBase<string>[] = []
    //This is a nightmare i know,but have look at bottom of this file (;
    for(let[fieldsKey, fieldsValue] of Object.entries(types)){
      if (typeof(fieldsValue) == 'object') {
        let validation = validations[fieldsKey].split("|")
        for(let [fieldkey, fieldValue] of Object.entries(fieldsValue) ){
          let optionsArray = []
          for(let [itemKey, itemValue] of Object.entries(data[fieldsKey]) ){
            optionsArray.push(
              {key: itemValue['id'],  value: itemValue[fieldkey]}
              )
            }
            formsInputs.push(
              new DropdownInput({
                key: fieldsKey,
                label: fieldsKey.toUpperCase(),
                options: optionsArray,
                order: fieldOrder++,
                isActive: true

                })
              )
            console.log('rei oi',[fieldkey])

          }
      }
      else if(fieldsValue == 'text'){
        let validation = validations[fieldsKey].split("|")

        formsInputs.push(
            new TextboxInput({
            key: fieldsKey,
            label: fieldsKey.toUpperCase(),
            value: data[fieldsKey],
            required: validation.includes("required") ? true : false,
            order: fieldOrder++,
            invalid: false
          })
        )
      }
    }


    // for(let field in types ){
    //   let validation = validations[field].split("|")
    //   switch (types[field]) {
    //     case 'text':
    //       formsInputs.push(
    //           new TextboxInput({
    //           key: field,
    //           label: field,
    //           value: data[field],
    //           required: validation.includes("required") ? true : false,
    //           order: fieldOrder++,
    //           invalid: false
    //         })
    //       )
    //       break;
    //     default:
    //       for(let fielde in data['permissions']){
    //           // console.log(fielde, data[field])
    //           formsInputs.push(
    //           new DropdownInput({
    //             key: 'permissions',
    //             label: 'Bravery Rating',
    //               options: [
    //                 {key: 'solid',  value: 'Solid'},
    //                 {key: 'great',  value: 'Great'},
    //                 {key: 'good',   value: 'Good'},
    //                 {key: 'unproven', value: 'Unproven'}
    //               ],
    //               order: 3
    //             })
    //           )
    //         }
    //       // for(let item in data[field]){
    //       //   console.log(item    )
    //       // }

    //       // console.log(types)
    //       // for (const [key, value] of Object.entries(data[])) {
    //       //   // for(const [keys, values] of Object.entries(value)){
    //       //   //     console.log(keys)
    //       //   // }
    //       // }
    //       // for(let fielde in data[field]){
    //       //   console.log(fielde, data[field])
    //       //   formsInputs.push(
    //       //   new DropdownInput({
    //       //     key: 'permissions',
    //       //     label: 'Bravery Rating',
    //       //       options: [
    //       //         {key: 'solid',  value: 'Solid'},
    //       //         {key: 'great',  value: 'Great'},
    //       //         {key: 'good',   value: 'Good'},
    //       //         {key: 'unproven', value: 'Unproven'}
    //       //       ],
    //       //       order: 3
    //       //     })
    //       //   )
    //       // }

    //     break;

    //     // default:
    //     //   break;
    //   }
    // }

    return formsInputs.sort((a, b) => a.order - b.order);
  }


  // getInputs() : DynamicInputBase<string>[]{
  getInputs(routeFragment:string): Observable<any> {

    // const quest = this.http.get<any>(this.API_URL+routeFragment+'/create', {});

    return this.http.get<any>(this.API_URL+routeFragment+'/create', {})
    // return quest;
    const questions: DynamicInputBase<string>[] = [
    // const questions = [

      new DropdownInput({
        key: 'brave',
        label: 'Bravery Rating',
        options: [
          {key: 'solid',  value: 'Solid'},
          {key: 'great',  value: 'Great'},
          {key: 'good',   value: 'Good'},
          {key: 'unproven', value: 'Unproven'}
        ],
        order: 3
      }),

      new TextboxInput({
        key: 'firstName',
        label: 'First name',
        value: 'Bombasto',
        required: true,
        order: 1
      }),

      new TextboxInput({
        key: 'emailAddress',
        label: 'Email',
        type: 'email',
        order: 2
      })
    ];

    return of(questions.sort((a, b) => a.order - b.order));
    // return questions;
  }


  sendData(urlFragment:string, formData:any):Observable<HttpResponse<any>>  {
    return this.http.post<any>(this.API_URL+urlFragment , formData, {  observe: 'response'  }).pipe()
  }

}



















// good luck ;D
