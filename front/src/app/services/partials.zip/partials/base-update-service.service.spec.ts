import { TestBed } from '@angular/core/testing';

import { BaseUpdateServiceService } from './base-update-service.service';

describe('BaseUpdateServiceService', () => {
  let service: BaseUpdateServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BaseUpdateServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
